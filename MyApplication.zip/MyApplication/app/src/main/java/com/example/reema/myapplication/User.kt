package com.example.reema.myapplication

import androidx.room.Entity

@Entity(tableName = "users")
data class User(
    var id : Int,
    var name : String
)