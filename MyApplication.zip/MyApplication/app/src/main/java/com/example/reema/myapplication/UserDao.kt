package com.example.reema.myapplication

import androidx.room.Dao

@Dao
interface UserDao{

}